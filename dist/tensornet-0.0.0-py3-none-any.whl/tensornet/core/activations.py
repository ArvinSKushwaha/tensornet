import numpy as np
from scipy.special import expit

activations = {
    "linear": [
        lambda x: x,
        lambda x: 1
    ],
    "sigmoid": [
        lambda x: expit(x),
        lambda x: expit(x)*(1-expit(x))
    ],
    "relu": [
        lambda x: 0 if x < 0 else x,
        lambda x: 0 if x < 0 else 1
    ]
}

class Activation(Layer):
    def __init__(self, fname="linear", function=None, d_function=None):
        super().__init__(self)
        if(function and d_function):
            self.func = function
            self.d_func = d_function
        else:
            self.func, self.d_func = activations[fname]
    def forward(self, x):
        return self.func(x)